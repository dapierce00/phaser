# Arcade Quiz Game

A Phaser-based arcade-style quiz game where teachers can input their own questions.

## Files

- `index.html` — loads Phaser and game logic
- `main.js` — game logic, loads questions
- `questions.json` — sample question set

## To Use

1. Upload to GitHub or Netlify
2. Replace `questions.json` with your own
3. Share the link with students
